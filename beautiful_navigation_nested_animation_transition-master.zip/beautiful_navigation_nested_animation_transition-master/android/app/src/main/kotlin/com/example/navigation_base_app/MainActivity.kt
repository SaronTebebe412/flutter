package com.example.navigation_base_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
