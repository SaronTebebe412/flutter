

class Places {
  int index;
  String placeTitle, placePath, placeSubTitle;
  Places({this.placeTitle, this.placeSubTitle ,this.placePath, this.index});

}