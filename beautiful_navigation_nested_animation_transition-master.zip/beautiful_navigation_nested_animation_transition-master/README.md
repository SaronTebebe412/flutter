# navigation_base_app - flutter

A beauitifull customized nested animation in screen navigation.

✔️ Sound NullSafety

## GIF

<p align="center">
  <img 
    width=40%
    height=40%
    src="https://user-images.githubusercontent.com/101565812/193448928-613c4e81-e9f0-4631-bc1c-e6d88445bf09.gif" >
</p>
